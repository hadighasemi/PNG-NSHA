===============================================================================
----------  EXTENDED GLOBAL EARTHQUAKE CATALOGUE FORMAT DESCRIPTION  ----------
===============================================================================

- 'eventID'

A unique identifier assigned to each earthquake
- 'Agency'

The catalogue source, or recording agency, from which the location is taken
- 'Identifier'

A string identifier indicating both the source agency from which the location 
is taken and the corresponding source agency and magnitude combination used for
homogenisation

- 'sourceIdentifier'

The original identifier of the event as provided by the location source

- 'year'

The year of the event (Common Era)

- 'month'

The month of the event

- 'day'

The day of the event

- 'hour'

The hour of the event (based on the time of the preferred location solution)

- 'minute'

The minute of the event (based on the time of the preferred location solution)

- 'second'

The second of the event (based on the time of the preferred location solution)

- 'timeError'

The error in the location time (seconds)

- 'longitude'

The longitude of the event in decimal degrees (centred on the Greenwich
Meridian)

- 'latitude'

The latitude of the event in decimal degrees

- 'SemiMajor90'

Length (in km) of the semi-major axis of the 90th percentile confidence ellipse

- 'SemiMinor90'

Length (in km) of the semi-minor axis of the 90th percentile confidence ellipse

- 'ErrorStrike'

Azimuth (degrees) of the semi-major axis of the 90th percentile confidence
ellipse

- 'depth'

Depth (km) of the hypocentre

- 'depthError'

Standard deviation (km) the location of the hypocentral depth

- 'magnitude'

Homogenised magnitude of the catalogue (effectively moment-magnitude Mw, or a
proxy equivalent)

- 'sigmaMagnitude'

Standard deviation of the magnitude esitmate
